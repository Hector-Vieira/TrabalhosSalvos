let quantidadedepessoas = document.querySelector ("#quantidadedepessoas")
let btcalcular = document.querySelector ("#btcalcular")
let Resultado = document.querySelector ("#Resultado")

function calculo(){
    let numerodepessoas = Number (quantidadedepessoas)
    let quantidadequeijo = Number (numerodepessoas*50)
    let quantidadedeovos = Number (quantidade)
}