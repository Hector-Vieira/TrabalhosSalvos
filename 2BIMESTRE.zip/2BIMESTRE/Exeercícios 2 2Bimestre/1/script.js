let cotacaoatual = document.querySelector ("#cotacaoatual")
let calcular = document.querySelector ("#calcular")
let Resultado1 = document.querySelector ("#Resultado1")
let Resultado2 = document.querySelector ("#Resultado2")
let Resultado3 = document.querySelector ("#Resultado3")
let Resultado4 = document.querySelector ("#Resultado4")

function calculo(){
    let valoratualdolar = Number (cotacaoatual.value)
    let mult1porcento = Number (valoratualdolar+(valoratualdolar*(1/100)))
    let mult2porcento = Number (valoratualdolar+(valoratualdolar*(2/100)))
    let mult5porcento = Number (valoratualdolar+(valoratualdolar*(5/100)))
    let mult10porcento = Number (valoratualdolar+(valoratualdolar*(10/100)))
    

    Resultado1.textContent = mult1porcento
    Resultado2.textContent = mult2porcento
    Resultado3.textContent = mult5porcento
    Resultado4.textContent = mult10porcento

}

calcular.onclick = function(){
    calculo()
}