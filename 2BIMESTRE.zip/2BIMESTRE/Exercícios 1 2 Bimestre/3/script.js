let saldo = document.querySelector ("#saldo")
let btcalcular = document.querySelector("#btcalcular")
let valorfinal = document.querySelector("#valorfinal")

function formulareajuste(){
    let valoratual = Number (saldo.value);
    let calculo = Number (valoratual+(valoratual*(1/100)))
    valorfinal.textContent = calculo
}

btcalcular.onclick = function(){
    formulareajuste()
}