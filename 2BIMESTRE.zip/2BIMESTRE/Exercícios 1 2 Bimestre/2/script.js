let valorkg = document.querySelector ("#valorkg")
let quantidadekg = document.querySelector ("#quantidadekg")
let btcalcular = document.querySelector ("#btcalcular")
let resultado = document.querySelector ("#resultado")


function valorfinal(){
    let precodokg = Number (valorkg.value);
    let quantidadedekg = Number (quantidadekg.value);
    let precofinal = (precodokg*quantidadedekg);

    resultado.textContent = precofinal
}

btcalcular.onclick = function(){
    valorfinal()
}