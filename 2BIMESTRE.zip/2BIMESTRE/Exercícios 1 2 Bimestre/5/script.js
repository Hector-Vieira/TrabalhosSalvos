let primeirovalor = document.querySelector ("#primeirovalor")
let segundovalor = document.querySelector ("#segundovalor")
let btcalcular = document.querySelector ("#btcalcular")
let Resultado = document.querySelector ("#Resultado")

function calculo(){
    let valorum = Number (primeirovalor.value)
    let valordois = Number (segundovalor.value)

    if (valorum>valordois){
        Resultado.textContent = "O valor "+valorum+" e maior"
    } else if(valordois>valorum){
        Resultado.textContent = "O valor "+valordois+" e maior"
    }
    else {
        Resultado.textContent = "Os valores sao iguais"
    }
}

btcalcular.onclick = function(){
    calculo()

}