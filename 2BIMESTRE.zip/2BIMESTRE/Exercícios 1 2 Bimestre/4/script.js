let primeironumero = document.querySelector ("#primeironumero")
let segundonumero = document.querySelector ("#segundonumero")
let terceironumero = document.querySelector ("#terceironumero")
let btcalcular = document.querySelector ("#btcalcular")
let resultado1 = document.querySelector ("#resultado1")
let resultado2 = document.querySelector ("#resultado2")
let resultado3 = document.querySelector ("#resultado3")
let Resultado4 = document.querySelector ("#Resultado4")

function medias(){
    let numeroum = Number (primeironumero.value)
    let numerodois = Number (segundonumero.value)
    let numerotres = Number (terceironumero.value)
    let media1 = Number ((numeroum + numerodois + numerotres) / 3)
    let media2 = Number ((numeroum*3+numerodois*2+numerotres*5)/(3+2+5))
    resultado1.textContent = media1

    resultado2.textContent = media2

    resultado3.textContent = media1 + media2

    Resultado4.textContent = (media1 + media2) / 2
}

btcalcular.onclick = function(){
    medias()
}
