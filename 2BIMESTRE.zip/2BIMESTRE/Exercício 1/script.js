let titulo = document.querySelector('#titulo');
let primeirovalor = document.querySelector('#primeirovalor');
let segundovalor = document.querySelector('#segundovalor');
let resultado = document.querySelector('#resultado');
let botaosoma = document.querySelector('#botaosoma');

function somarvalores(){
    let valor1 = Number (primeirovalor.value);
    let valor2 = Number (segundovalor.value);
    let soma = valor1+valor2

    resultado.textContent = soma
}
 botaosoma.onclick = function(){
    somarvalores();
 } 