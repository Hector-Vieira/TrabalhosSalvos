let valorpago = document.querySelector("#valorpago");
let valorproduto = document.querySelector("#valorproduto");
let btcalculo = document.querySelector("#btcalculo");
let resultado = document.querySelector("#resultado")

function valordotroco(){
    let valorrecebido = Number (valorpago.value);
    let valordoproduto = Number (valorproduto.value);
    let valoradevolver = (valorrecebido-valordoproduto);

    resultado.textContent = valoradevolver;
}

btcalculo.onclick = function(){
    valordotroco()
}