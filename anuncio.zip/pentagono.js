function iniciarAnimacaoPentagono(containerId) {

    // 1. Encontrar o container
    const animationContainer = document.getElementById(containerId);

    if (!animationContainer) {
        console.error(`[animacaoPentagono] Elemento com ID "${containerId}" não foi encontrado.`);
        return;
    }

    // 2. Garantir que o container tenha os estilos corretos
    const computedStyle = window.getComputedStyle(animationContainer);
    if (computedStyle.position === 'static') {
        animationContainer.style.position = 'relative';
    }
    if (computedStyle.overflow !== 'hidden') {
        animationContainer.style.overflow = 'hidden';
    }

    // 3. Injetar os estilos CSS necessários (apenas uma vez)
    if (!document.getElementById('pentagon-animation-styles')) {
        const style = document.createElement('style');
        style.id = 'pentagon-animation-styles';
        style.innerHTML = `
            .pentagon-shape {
                position: absolute;
                top: 0;
                right: -100px;
                border: 1px solid rgba(51, 51, 51, 0.3); /* Cinza escuro com opacidade */
                background-color: transparent;
                opacity: 0; /* Começa invisível */

                clip-path: polygon(50% 0%, 100% 38%, 82% 100%, 18% 100%, 0% 38%);

                /* Animação */
                animation: moveLeftPentagon linear, fadeInPentagon 1s ease-out forwards;
                pointer-events: none;
            }

            @keyframes moveLeftPentagon {
                from {
                    transform: translateX(0);
                }
                to {
                    /* Ajustado para -100vw para garantir que saia da tela */
                    transform: translateX(-100vw);
                }
            }

            @keyframes fadeInPentagon {
                from {
                    opacity: 0;
                }
                to {
                    opacity: 0.15; /* Opacidade final bem sutil */
                }
            }
        `;
        document.head.appendChild(style);
    }

    /**
     * Função interna para criar e animar um único pentágono.
     */
    function criarPentagono() {
        // Não cria pentágonos se o container não estiver visível
        if (animationContainer.offsetParent === null) {
            return;
        }

        const shape = document.createElement('div');
        shape.classList.add('pentagon-shape');

        // Tamanhos menores, mais sutis para os cards
        const size = Math.floor(Math.random() * (60 - 20) + 20); // Tamanho entre 20px e 60px
        shape.style.width = `${size}px`;
        shape.style.height = `${size}px`;

        // Posição vertical aleatória dentro do card
        const maxHeight = animationContainer.offsetHeight - size;
        const topPosition = Math.floor(Math.random() * maxHeight);
        shape.style.top = `${Math.max(0, topPosition)}px`;

        // Duração aleatória da animação
        const duration = Math.random() * (20 - 10) + 10; // Duração entre 10s e 20s
        shape.style.animationDuration = `${duration}s, 1s`; // Duração para moveLeft, Duração para fadeIn

        animationContainer.appendChild(shape);

        // Limpeza: Remove o pentágono do DOM após a animação terminar
        setTimeout(() => {
            if (shape.parentNode) {
                shape.remove();
            }
        }, duration * 1000);
    }

    // Iniciar o gerador de pentágonos
    // Cria um novo pentágono em intervalos mais longos para ser mais sutil
    const intervalId = setInterval(criarPentagono, 2500); // Cria um a cada 2.5 segundos

    // Opcional: Para parar a animação se o elemento for removido
    // (Útil em aplicações de página única - SPA)
    const observer = new MutationObserver((mutations, obs) => {
        if (!document.body.contains(animationContainer)) {
            clearInterval(intervalId); // Para de criar novos pentágonos
            obs.disconnect(); // Para de observar
        }
    });
    observer.observe(document.body, { childList: true, subtree: true });
}